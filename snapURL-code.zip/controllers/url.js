const { URL: NodeURL } = require('url');
const URL = require('../models/url');

const isValidUrl = (url) => {
    try {
        new NodeURL(url);
        return true;
    } catch (err) {
        return false;
    }
};

const generateLetterOnlyId = (length = 6) => {
    const characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
};

async function generateShortId(req, res) {
    try {
        let { url, customName } = req.body;

        if (!url || !isValidUrl(url)) {
            return res.render('home', { error: 'Please enter a valid URL.' });
        }

        if (!/^(http:\/\/|https:\/\/)/i.test(url)) {
            url = 'http://' + url;
        }

        let shortID = customName || generateLetterOnlyId();

        while (true) {
            try {
                await URL.create({ shortid: shortID, redirectURL: url });
                break;
            } catch (error) {
                if (error.code === 11000) {
                    if (customName) {
                        return res.render('home', { error: 'Custom name already taken.' });
                    }
                    shortID = generateLetterOnlyId();
                } else {
                    throw error;
                }
            }
        }

        const baseUrl = process.env.BASE_URL || `http://localhost:${process.env.PORT || 8001}`;
        res.render('home', { id: `${baseUrl}/${shortID}` });

    } catch (error) {
        res.status(500).render('home', { error: 'Internal Server Error.' });
    }
}

module.exports = { generateShortId };
