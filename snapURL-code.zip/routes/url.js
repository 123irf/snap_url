const express = require('express');
const router = express.Router();
const { generateShortId } = require('../controllers/url.js'); // Ensure this is correct

router.post('/', generateShortId); // Ensure this function is correctly defined
module.exports = router;
